CREATE TRIGGER sad
  BEFORE INSERT
  ON aa
  FOR EACH ROW
  begin
set new.c=(new.a+new.b) ;
end;

