CREATE TRIGGER bm
  BEFORE UPDATE
  ON tb_zy
  FOR EACH ROW
  begin
update tb_bm set fzr=new.name where tb_bm.bmid=new.bmid and new.zw='部长';
end;

