CREATE TRIGGER sjgz
  BEFORE UPDATE
  ON tb_gz
  FOR EACH ROW
  begin
set new.sjgz=new.jbgz+new.jf;
end;

