CREATE TRIGGER jf
  BEFORE UPDATE
  ON tb_jc
  FOR EACH ROW
  begin
update tb_gz set jf=new.jcje where tb_gz.zyid=new.zyid;
end;

